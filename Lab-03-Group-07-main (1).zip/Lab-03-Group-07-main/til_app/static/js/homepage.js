// homepage.js

$('.navTrigger').click(function () {
  $(this).toggleClass('active');
  console.log("Clicked menu");
  $("#mainListDiv").toggleClass("show_list");
  $("#mainListDiv").fadeIn();
});

$(window).scroll(function() {
if ($(document).scrollTop() > 50) {
  $('.nav').addClass('affix');
} else {
  $('.nav').removeClass('affix');
}
});

